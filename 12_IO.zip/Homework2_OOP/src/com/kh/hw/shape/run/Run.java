package com.kh.hw.shape.run;

import com.kh.hw.shape.view.ShapeMenu;

public class Run {

	public static void main(String[] args) {
		ShapeMenu sm = new ShapeMenu();
		sm.inputMenu();

	}

}
