package com.kh.hw.employee.controller;

import com.kh.hw.employee.model.vo.Employee;

public class EmployeeController {
	Employee e = new Employee();
	
	public void add(int empNo, String name, char gender, String phone) {
		
	}
	
	public void add(int empNo, String name, char gender, String phone, String dept, int salary, double bonus) {
		
	}
	
	public void modify(String phone) {
		
	}
	
	public void modify(int salary) {
		
	}
	
	public void modify(double bonus) {
		
	}
	
	// 객체 삭제?
	public void remove() {
		
	}
	
	public String inform() {
		return "";
	}
}
