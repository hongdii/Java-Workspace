package pakage3.controller;

public class AnimalManager {

	public static void main(String[] args) {
		
	}

}
