package com.kh.hw.person.run;

import com.kh.hw.person.view.PersonMenu;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new PersonMenu().mainMenu();
	}

}
