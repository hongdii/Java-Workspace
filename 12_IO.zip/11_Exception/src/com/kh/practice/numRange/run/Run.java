package com.kh.practice.numRange.run;

import com.kh.practice.numRange.view.NumberMenu;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NumberMenu nm = new NumberMenu();
		nm.menu();
	}

}
