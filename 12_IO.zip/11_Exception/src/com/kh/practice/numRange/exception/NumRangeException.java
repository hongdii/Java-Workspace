package com.kh.practice.numRange.exception;

public class NumRangeException extends RuntimeException{

	public NumRangeException() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public NumRangeException(String msg) {
		super(msg);
	}
}
