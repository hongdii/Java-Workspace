package com.kh.practice.model.vo;

public interface CellPhone extends Phone, Camera{
	
	public String charge();
}
