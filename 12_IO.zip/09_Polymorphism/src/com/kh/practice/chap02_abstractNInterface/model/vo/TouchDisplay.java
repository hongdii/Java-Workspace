package com.kh.practice.model.vo;

public interface TouchDisplay {

	public String touch();
}
