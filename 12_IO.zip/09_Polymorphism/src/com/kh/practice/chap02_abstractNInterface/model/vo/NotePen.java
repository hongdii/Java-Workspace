package com.kh.practice.model.vo;

public interface NotePen {

	public boolean PEN_BUTTON = true;
	
	public boolean bluetoothPen();
}
