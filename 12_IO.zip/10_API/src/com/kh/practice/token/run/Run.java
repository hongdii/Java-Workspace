package com.kh.practice.token.run;

import com.kh.practice.token.view.*;

public class Run {

	public static void main(String[] args) {
		new TokenMenu().mainMenu();
	}

}
