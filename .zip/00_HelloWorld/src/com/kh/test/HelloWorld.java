package com.kh.test;

public class HelloWorld {
	//안녕
	/* 메인메소드 ? 자바 애플리케이션, 자바프로그램이 시작되는 시작점 (entry point)
	 * 따라서 하나의 자바 애플리케이션에는 1개 이상의 main 메서드가 포함된 클래스가 존재해야한다.
	 * 안
	 * 녕
	 */
	
	
	public static void main(String[] args){ // 메인 메서드, static 고정된 영역, 메서드 형태 외워두기(쓰는것 시험에 나올수도)
		System.out.println("Hello World!"); // 출력문 아래있는 콘솔창 ("문자열") 들어간 값을 출력해준다.
	}
	
}