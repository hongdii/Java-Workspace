package com.kh.name;

public class Myname {
	
	//메인 메서드가 아닌 메서드(일반 메서드)
	// 일반 메서드는 메인 메서드와 달리 혼자서 실행되지 않음. 일반 메서드는 호출해야 실행됨.
	public void callMyName() {
		System.out.println("안녕하세요 제 이름은 오현지입니다.");
	}
}
