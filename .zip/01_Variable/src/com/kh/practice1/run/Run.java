package com.kh.practice1.run;
import com.kh.practice1.func.*;

public class Run {
	
	public static void main(String[] args) {
		VariablePractice1 vp = new VariablePractice1();
		//vp.test1();
		
		VariablePractice2 vp2 = new VariablePractice2();
		//vp2.test2();
		
		VariablePractice3 vp3 = new VariablePractice3();
		//vp3.test3();
		
		VariablePractice4 vp4 = new VariablePractice4();
		vp4.test4();
	}
}
