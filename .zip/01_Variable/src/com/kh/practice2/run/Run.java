package com.kh.practice2.run;
import com.kh.practice2.func.*;

public class Run {
	
	public static void main(String[] args) {
		CastingPractice cp = new CastingPractice();
		//cp.test();
		
		CastingPractice3 cp2 = new CastingPractice3();
		cp2.method();
	}
	
}
