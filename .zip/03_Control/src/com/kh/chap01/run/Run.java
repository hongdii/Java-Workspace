package com.kh.chap01.run;
import com.kh.chap01.condition.*;

public class Run {
	
	public static void main(String [] args) {
		A_If ai = new A_If();
		//ai.method7();
		
		B_Switch as = new B_Switch();
		as.method3();
	}
}
