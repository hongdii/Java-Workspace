package com.kh.chap03.run;
import com.kh.chap03.branch.*;

public class Run {
	public static void main(String[] args) {	//ctrl+spacebar+enter : main문 자동완성
		A_Break ab = new A_Break();
		//ab.method3();
		
		B_Continue bc = new B_Continue();
		bc.method3();
	}
}
