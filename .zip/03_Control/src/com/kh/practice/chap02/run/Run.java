package com.kh.practice.chap02.run;
import com.kh.practice.chap02.loop.*;

public class Run {
	public static void main(String[] args) {
		LoopPractice lp = new LoopPractice();
		lp.practice19();
		
		B_While bw = new B_While() ;
		//bw.method7();
		
		
	}
}

