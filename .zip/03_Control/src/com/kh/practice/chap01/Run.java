package com.kh.practice.chap01;
import com.kh.practice.chap01.*;

public class Run {
	public static void main(String [] args) {
		ControlPractice cp = new ControlPractice(); 
		cp.practice10();
	}
}
