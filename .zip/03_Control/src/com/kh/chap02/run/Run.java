package com.kh.chap02.run;
import com.kh.chap02.loop.*;

public class Run {
	public static void main(String[] args) {
		A_For af = new A_For();
		af.method16();
	}
}
