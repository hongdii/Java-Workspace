package com.kh.example.practice4.run;
import com.kh.example.practice4.model.vo.Student;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1 = new Student();
		s1.setClassroom(1);
		s1.setGender('여');
		s1.setGrade(4);
		s1.setHeight(162.2);
		s1.setName("오현지");
		
		s1.information();
	}

}
