package com.kh.example.practice6.run;
import com.kh.example.practice6.modle.vo.Book;

public class Run {
	public static void main(String[] args) {
		Book b1 = new Book();
		b1.title = "용의자x의 헌신";
		b1.pulbisher = "몰라"
		"히가시노게이고"
	}
}
