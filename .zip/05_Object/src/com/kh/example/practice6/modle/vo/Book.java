package com.kh.example.practice6.modle.vo;

public class Book {
	private String title;
	private String pulbisher;
	private String author;
	private int price;
	private double discountRate;
	
	public Book() {
		
	}
	
	public Book(String title, String publisher, String author) {
		this.title = title;
		this.pulbisher = pulbisher;
		this.author = author; 
	}
	
	public Book(String title, String publisher, String author, int price, double discountRate) {
		this(title, pulbisher, author);
		this.price = price;
		this.discountRate = discountRate;
		
	}
	
	public void inform() {
		
	}
}
