package com.kh.example.practice3.run;
import com.kh.example.practice3.model.vo.*;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle c = new Circle();
		c.incrementRadius(1);
		c.getAreaOfCircle();
		c.getSizeOfCircle();
//		System.out.println("원의 둘레 : "+c.getAreaOfCircle()+", "
//		+"원의 넓이 : "+c.getSizeOfCircle());
	}

}
