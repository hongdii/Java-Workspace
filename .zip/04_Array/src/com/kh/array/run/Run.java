package com.kh.array.run;
import com.kh.array.*;

public class Run {
	public static void main(String[] args) {
		A_Array aa = new A_Array();
		//aa.method12();
		
		ArrayPractice ap = new ArrayPractice();
		//ap.practice8();
		
		B_ArrayCopy bac = new B_ArrayCopy();
		//bac.method5();
		
		C_DimensionalArray cda = new C_DimensionalArray();
		cda.method7();
	}
}
