package com.kh.practice.run;
import com.kh.practice.func.*;

public class Run {
	
	public static void main(String[] args) {
		
		OperatorPractice1 op1 = new OperatorPractice1();
		//op1.test1();
		
		practice2 p2 = new practice2();
		//p2.test2();
		
		practice3 p3 = new practice3();
		//p3.test3();

		practice4 p4 = new practice4();
		//p4.test4();
		//p4.test5();
		//p4.test6();
		p4.test8();
	}
}
