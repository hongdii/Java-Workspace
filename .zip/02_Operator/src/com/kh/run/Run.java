package com.kh.run;
import com.kh.operator.*;

public class Run {
	
	public static void main(String[] args) {
		A_Arithmetic aa = new A_Arithmetic();
		//aa.method();
		
		B_InDecrease bi = new B_InDecrease();
		//bi.method();
		//bi.method2();
		//bi.method3();
		//bi.method4();
		//bi.quiz();
		
		C_Compound cc = new C_Compound();
		//cc.method();
		
		D_LogicalNegation dl = new D_LogicalNegation();
		//dl.method();
		
		E_Comparison ec = new E_Comparison();
		//ec.method1();
		//ec.method2();
		
		F_Logical fl = new F_Logical();
		//fl.method1();
		//fl.method2();
		//fl.method3();
		//fl.method4();
		
		G_Triple gt = new G_Triple();
		//gt.method1();
		//gt.method2();
		//gt.method3();
		//gt.method4();
		gt.method5();

		
	}
}
